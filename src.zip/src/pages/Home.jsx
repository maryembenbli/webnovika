import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { CategoriesAPI } from "../api/categories.api";
import { ProductsAPI } from "../api/products.api";
import { AppShell } from "../components/AppShell";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:3000";

function imgUrl(path) {
  if (!path) return "";
  if (path.startsWith("http")) return path;
  return `${API_URL}${path}`;
}

function normalize(value) {
  return String(value || "").trim().toLowerCase();
}

export default function Home() {
  const navigate = useNavigate();
  const [products, setProducts] = useState([]);
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("all");

  useEffect(() => {
    let mounted = true;

    const load = async () => {
      try {
        const [productData, categoryData] = await Promise.all([
          ProductsAPI.list(),
          CategoriesAPI.list(),
        ]);

        if (!mounted) return;
        setProducts(Array.isArray(productData) ? productData : []);
        setCategories(
          Array.isArray(categoryData) ? categoryData.filter((item) => item?.isActive !== false) : []
        );
      } catch (requestError) {
        console.error(requestError);
        if (mounted) setError("Impossible de charger les donnees du catalogue.");
      } finally {
        if (mounted) setLoading(false);
      }
    };

    load();

    return () => {
      mounted = false;
    };
  }, []);

  const filtered = useMemo(() => {
    const needle = normalize(query);

    return products.filter((product) => {
      const title = normalize(product.title || product.name);
      const brand = normalize(product.brand);
      const matchesSearch = !needle || title.includes(needle) || brand.includes(needle);

      const productCategories = Array.isArray(product.categories)
        ? product.categories.map((item) => normalize(item))
        : [];
      const matchesCategory =
        activeCategory === "all" || productCategories.includes(normalize(activeCategory));

      return matchesSearch && matchesCategory;
    });
  }, [activeCategory, products, query]);

  return (
    <AppShell searchValue={query} onSearchChange={setQuery}>
      <section className="hero">
        <div className="heroInner">
          <div>
            <div className="pill">Collection 2026</div>
            <h1 className="heroTitle">Une vitrine claire, rapide et prete a commander.</h1>
            <p className="heroSub">
              Produits, categories et commandes utilisent maintenant la meme direction visuelle.
            </p>
            <div className="heroBtns">
              <button className="primaryBtn" type="button" onClick={() => window.scrollTo(0, 520)}>
                Voir les produits
              </button>
              <button className="ghostBtn" type="button" onClick={() => navigate("/cart")}>
                Suivre les commandes
              </button>
            </div>
          </div>

          <div className="heroCard">
            <div className="heroCardTitle">Pilotage simplifie</div>
            <div className="heroCardDesc">
              Catalogue filtre par categorie, details propres et tunnel de commande unique.
            </div>
            <div className="heroStats">
              <div className="stat">
                <div className="statN">{products.length}</div>
                <div className="statT">Produits</div>
              </div>
              <div className="stat">
                <div className="statN">{categories.length}</div>
                <div className="statT">Categories</div>
              </div>
              <div className="stat">
                <div className="statN">{filtered.length}</div>
                <div className="statT">Resultats</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <main className="container">
        <section className="surface">
          <div className="sectionHead sectionHeadStack">
            <div>
              <h2 className="sectionTitle">Catalogue</h2>
              <div className="sectionMeta">
                {loading ? "Chargement..." : `${filtered.length} produit(s) disponibles`}
              </div>
            </div>
            <div className="catBar">
              <button
                type="button"
                className={`chip ${activeCategory === "all" ? "active" : ""}`}
                onClick={() => setActiveCategory("all")}
              >
                Tous
                <span className="chipCount">{products.length}</span>
              </button>

              {categories.map((category) => {
                const name = String(category.name || "");
                const count = products.filter((product) =>
                  Array.isArray(product.categories)
                    ? product.categories.map((item) => normalize(item)).includes(normalize(name))
                    : false
                ).length;

                return (
                  <button
                    key={String(category._id || category.id || category.name)}
                    type="button"
                    className={`chip ${activeCategory === name ? "active" : ""}`}
                    onClick={() => setActiveCategory(name)}
                  >
                    {name}
                    <span className="chipCount">{count}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {error ? (
            <div className="errorBox">
              <div>{error}</div>
              <button className="ghostBtn" type="button" onClick={() => window.location.reload()}>
                Recharger
              </button>
            </div>
          ) : loading ? (
            <div className="grid">
              {Array.from({ length: 8 }).map((_, index) => (
                <div className="card sk" key={index}>
                  <div className="skImg" />
                  <div className="skLine" />
                  <div className="skLine sm" />
                </div>
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="empty">Aucun produit ne correspond a votre recherche.</div>
          ) : (
            <div className="grid">
              {filtered.map((product) => {
                const id = String(product._id || product.id);
                const title = product.title || product.name || "Produit";
                const price = Number(product.price ?? 0);
                const oldPrice = Number(product.oldPrice ?? 0);
                const cover = Array.isArray(product.images) ? product.images[0] : product.image;
                const inStock = Number(product.stock ?? 0) > 0;

                return (
                  <button
                    key={id}
                    className="card"
                    type="button"
                    onClick={() => navigate(`/product/${id}`)}
                  >
                    <div className="cardImg">
                      {cover ? (
                        <img src={imgUrl(cover)} alt={title} loading="lazy" />
                      ) : (
                        <div className="placeholder">No image</div>
                      )}

                      <div className={`badge ${inStock ? "ok" : "out"}`}>
                        {inStock ? "En stock" : "Rupture"}
                      </div>
                    </div>

                    <div className="cardBody">
                      <div className="cardTitle">{title}</div>
                      <div className="cardRow">
                        <div className="priceBox">
                          <div className="price">{price.toFixed(2)} DT</div>
                          {oldPrice > price ? (
                            <div className="oldPrice">{oldPrice.toFixed(2)} DT</div>
                          ) : null}
                        </div>

                        <div className="cta">Details</div>
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          )}
        </section>

        <footer className="footer">
          <div>© {new Date().getFullYear()} Novika Shop</div>
          <div className="footerLinks">
            <span>Catalogue</span>
            <span>Commandes</span>
            <span>Support</span>
          </div>
        </footer>
      </main>
    </AppShell>
  );
}
