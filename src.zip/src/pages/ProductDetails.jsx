import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { OrdersAPI } from "../api/orders.api";
import { ProductsAPI } from "../api/products.api";
import { AppShell } from "../components/AppShell";

const API_URL = import.meta.env.VITE_API_URL || "http://localhost:3000";

function imgUrl(path) {
  if (!path) return "";
  if (path.startsWith("http")) return path;
  return `${API_URL}${path}`;
}

function QuantityPicker({ value, onChange }) {
  return (
    <div className="qty">
      <button type="button" className="qtyBtn" onClick={() => onChange(Math.max(1, value - 1))}>
        -
      </button>
      <div className="qtyVal">{value}</div>
      <button type="button" className="qtyBtn" onClick={() => onChange(value + 1)}>
        +
      </button>
    </div>
  );
}

function ProductGallery({ images, title }) {
  const [active, setActive] = useState(0);

  useEffect(() => {
    setActive(0);
  }, [images]);

  const main = images[active] || images[0];

  return (
    <div className="gallery">
      <div className="galleryMain">
        {main ? <img src={main} alt={title} /> : <div className="placeholder">Aucune image</div>}
      </div>

      {images.length > 1 ? (
        <div className="thumbs">
          {images.map((src, index) => (
            <button
              type="button"
              key={`${src}-${index}`}
              className={`thumb ${index === active ? "active" : ""}`}
              onClick={() => setActive(index)}
            >
              <img src={src} alt={`${title}-${index}`} />
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}

export default function ProductDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [qty, setQty] = useState(1);
  const [form, setForm] = useState({
    fullName: "",
    phone: "",
    city: "",
    address: "",
    note: "",
  });

  useEffect(() => {
    let mounted = true;

    ProductsAPI.byId(id)
      .then((data) => {
        if (mounted) setProduct(data);
      })
      .catch((error) => {
        console.error(error);
        if (mounted) setProduct(null);
      })
      .finally(() => {
        if (mounted) setLoading(false);
      });

    return () => {
      mounted = false;
    };
  }, [id]);

  const title = product?.title || product?.name || "Produit";
  const productId = String(product?._id || product?.id || "");
  const unitPrice = Number(product?.price || 0);
  const deliveryFee = Number(product?.deliveryFee || 0);
  const oldPrice = Number(product?.oldPrice || 0);
  const inStock = Number(product?.stock ?? 0) > 0;

  const images = useMemo(() => {
    const rawImages = [
      ...(Array.isArray(product?.images) ? product.images : []),
      ...(product?.image ? [product.image] : []),
    ];

    return rawImages.filter(Boolean).map(imgUrl);
  }, [product]);

  const subtotal = unitPrice * qty;
  const total = subtotal + deliveryFee;

  const submitOrder = async () => {
    if (!productId) return window.alert("Produit introuvable.");
    if (!form.fullName.trim() || !form.phone.trim()) {
      return window.alert("Nom et telephone sont obligatoires.");
    }

    const payload = {
      customerName: form.fullName.trim(),
      phone: form.phone.trim(),
      city: form.city.trim() || undefined,
      address: form.address.trim() || undefined,
      customerNote: form.note.trim() || undefined,
      items: [
        {
          product: productId,
          quantity: qty,
          price: unitPrice,
          deliveryFee,
        },
      ],
    };

    try {
      setSending(true);
      await OrdersAPI.create(payload);
      window.alert("Commande enregistree avec succes.");
      setForm({ fullName: "", phone: "", city: "", address: "", note: "" });
      setQty(1);
      navigate("/cart");
    } catch (error) {
      console.error(error);
      window.alert("La commande a echoue. Verifiez les champs et le backend.");
    } finally {
      setSending(false);
    }
  };

  return (
    <AppShell title="Novika Shop" subtitle="Details produit et commande">
      <main className="container pageSection">
        {loading ? (
          <div className="surface">Chargement...</div>
        ) : !product ? (
          <div className="surface">
            <div className="empty">Produit introuvable.</div>
            <button type="button" className="ghostBtn" onClick={() => navigate("/")}>
              Retour au catalogue
            </button>
          </div>
        ) : (
          <>
            <div className="breadcrumb">
              <button type="button" className="linkBtn" onClick={() => navigate("/")}>
                Boutique
              </button>
              <span className="crumbSep">/</span>
              <span className="crumbCurrent">{title}</span>
            </div>

            <div className="pdLayout">
              <section className="pdCard">
                <div className="pdTopRow">
                  <span className={`pill2 ${inStock ? "ok" : "out"}`}>
                    {inStock ? "Disponible" : "Stock indisponible"}
                  </span>
                  <span className="brandTag2">{product?.brand || "Novika selection"}</span>
                </div>

                <h1 className="pdTitle">{title}</h1>
                <div className="pdPriceRow">
                  <div className="pdPrice">{unitPrice.toFixed(2)} DT</div>
                  {oldPrice > unitPrice ? (
                    <div className="pdOldPrice">{oldPrice.toFixed(2)} DT</div>
                  ) : null}
                </div>

                <ProductGallery images={images} title={title} />

                <div className="pdDesc">
                  <div className="pdSectionTitle">Description</div>
                  <p className="pdText">{product?.description || "Aucune description disponible."}</p>
                </div>
              </section>

              <aside className="orderCard">
                <div className="orderHeader">
                  <div className="orderTitle2">Commander maintenant</div>
                  <div className="orderHint">Le formulaire suit le meme layout que le reste du site.</div>
                </div>

                <div className="formGrid">
                  <div className="field">
                    <label>Nom complet</label>
                    <input
                      value={form.fullName}
                      onChange={(event) =>
                        setForm((current) => ({ ...current, fullName: event.target.value }))
                      }
                    />
                  </div>
                  <div className="field">
                    <label>Telephone</label>
                    <input
                      value={form.phone}
                      onChange={(event) =>
                        setForm((current) => ({ ...current, phone: event.target.value }))
                      }
                    />
                  </div>
                  <div className="field">
                    <label>Ville</label>
                    <input
                      value={form.city}
                      onChange={(event) =>
                        setForm((current) => ({ ...current, city: event.target.value }))
                      }
                    />
                  </div>
                  <div className="field">
                    <label>Adresse</label>
                    <input
                      value={form.address}
                      onChange={(event) =>
                        setForm((current) => ({ ...current, address: event.target.value }))
                      }
                    />
                  </div>
                  <div className="field full">
                    <label>Note client</label>
                    <input
                      value={form.note}
                      onChange={(event) =>
                        setForm((current) => ({ ...current, note: event.target.value }))
                      }
                    />
                  </div>
                </div>

                <div className="orderBottom">
                  <div className="rowBetween">
                    <span className="muted">Quantite</span>
                    <QuantityPicker value={qty} onChange={setQty} />
                  </div>

                  <div className="totals2">
                    <div className="trow">
                      <span>Sous-total</span>
                      <span>{subtotal.toFixed(2)} DT</span>
                    </div>
                    <div className="trow">
                      <span>Livraison</span>
                      <span>{deliveryFee.toFixed(2)} DT</span>
                    </div>
                    <div className="trow total">
                      <span>Total</span>
                      <span>{total.toFixed(2)} DT</span>
                    </div>
                  </div>

                  <button
                    type="button"
                    className="primaryWide"
                    onClick={submitOrder}
                    disabled={sending || !inStock}
                  >
                    {sending ? "Envoi..." : "Valider la commande"}
                  </button>
                  <button type="button" className="ghostWide" onClick={() => navigate("/")}>
                    Continuer les achats
                  </button>
                </div>
              </aside>
            </div>
          </>
        )}
      </main>
    </AppShell>
  );
}
