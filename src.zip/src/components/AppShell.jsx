import { NavLink, useNavigate } from "react-router-dom";
import logo from "../assets/logo.png";

export function AppShell({
  children,
  searchValue = "",
  onSearchChange,
  title = "Novika Shop",
  subtitle = "Catalogue moderne et commandes rapides",
}) {
  const navigate = useNavigate();

  return (
    <div className="shopShell">
      <header className="topbar">
        <div className="topbarInner">
          <button className="brand" type="button" onClick={() => navigate("/")}>
            <div className="brandLogo brandLogoImage">
              <img src={logo} alt="Novika" />
            </div>
            <div className="brandText">
              <div className="brandName">{title}</div>
              <div className="brandTag">{subtitle}</div>
            </div>
          </button>

          <div className="searchWrap">
            <input
              value={searchValue}
              onChange={(event) => onSearchChange?.(event.target.value)}
              placeholder="Rechercher un produit, une marque..."
              className="searchInput"
            />
            <div className="searchIcon">Search</div>
          </div>

          <nav className="actions actionsNav">
            <NavLink to="/" className={({ isActive }) => `navLink ${isActive ? "active" : ""}`}>
              Boutique
            </NavLink>
            <NavLink
              to="/cart"
              className={({ isActive }) => `navLink navLinkAccent ${isActive ? "active" : ""}`}
            >
              Commandes
            </NavLink>
          </nav>
        </div>
      </header>

      {children}
    </div>
  );
}
